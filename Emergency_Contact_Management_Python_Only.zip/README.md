# Emergency Contact Management — Python Only

## Requirements
- Python 3.10+
- pip

## Run
Open a terminal in this folder and run:

```bash
pip install -r requirements.txt
python app.py
```

Then open http://127.0.0.1:5000 in your browser.

The SQLite database (`contacts.db`) is created automatically on startup.
