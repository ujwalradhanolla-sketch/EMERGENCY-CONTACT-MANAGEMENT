from flask import Flask, request, jsonify, render_template, redirect, url_for, flash
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-for-production"
DB_PATH = Path(__file__).with_name("contacts.db")

def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                service TEXT NOT NULL,
                phone TEXT NOT NULL,
                location TEXT NOT NULL
            )
        """)

def clean_contact(data):
    fields = ("name", "service", "phone", "location")
    cleaned = {key: str(data.get(key, "")).strip() for key in fields}
    missing = [key for key, value in cleaned.items() if not value]
    if missing:
        raise ValueError("Please fill in all fields.")
    if len(cleaned["name"]) > 100 or len(cleaned["service"]) > 100 or len(cleaned["location"]) > 150:
        raise ValueError("Name, service, or location is too long.")
    if len(cleaned["phone"]) > 30:
        raise ValueError("Phone number is too long.")
    return cleaned

@app.get("/")
def index():
    query = request.args.get("q", "").strip()
    with connect_db() as conn:
        if query:
            like = f"%{query}%"
            contacts = conn.execute(
                """SELECT * FROM contacts
                   WHERE name LIKE ? OR service LIKE ? OR phone LIKE ? OR location LIKE ?
                   ORDER BY name COLLATE NOCASE""", (like, like, like, like)
            ).fetchall()
        else:
            contacts = conn.execute("SELECT * FROM contacts ORDER BY name COLLATE NOCASE").fetchall()
    return render_template("index.html", contacts=contacts, query=query)

@app.post("/contacts")
def add_contact():
    try:
        contact = clean_contact(request.form)
        with connect_db() as conn:
            conn.execute(
                "INSERT INTO contacts (name, service, phone, location) VALUES (?, ?, ?, ?)",
                tuple(contact.values())
            )
        flash("Contact added successfully.", "success")
    except ValueError as exc:
        flash(str(exc), "error")
    return redirect(url_for("index"))

@app.post("/contacts/<int:contact_id>/update")
def update_contact(contact_id):
    try:
        contact = clean_contact(request.form)
        with connect_db() as conn:
            cursor = conn.execute(
                """UPDATE contacts SET name=?, service=?, phone=?, location=? WHERE id=?""",
                (*contact.values(), contact_id)
            )
            if cursor.rowcount == 0:
                flash("Contact not found.", "error")
            else:
                flash("Contact updated successfully.", "success")
    except ValueError as exc:
        flash(str(exc), "error")
    return redirect(url_for("index"))

@app.post("/contacts/<int:contact_id>/delete")
def delete_contact(contact_id):
    with connect_db() as conn:
        conn.execute("DELETE FROM contacts WHERE id=?", (contact_id,))
    flash("Contact deleted if it existed.", "success")
    return redirect(url_for("index"))

@app.get("/api/contacts")
def api_list():
    with connect_db() as conn:
        rows = conn.execute("SELECT * FROM contacts ORDER BY name COLLATE NOCASE").fetchall()
    return jsonify([dict(row) for row in rows])

@app.post("/api/contacts")
def api_add():
    try:
        contact = clean_contact(request.get_json(silent=True) or {})
        with connect_db() as conn:
            cursor = conn.execute(
                "INSERT INTO contacts (name, service, phone, location) VALUES (?, ?, ?, ?)",
                tuple(contact.values())
            )
            contact_id = cursor.lastrowid
        return jsonify({"id": contact_id, **contact}), 201
    except ValueError as exc:
        return jsonify({"message": str(exc)}), 400

@app.put("/api/contacts/<int:contact_id>")
def api_update(contact_id):
    try:
        contact = clean_contact(request.get_json(silent=True) or {})
        with connect_db() as conn:
            cursor = conn.execute(
                "UPDATE contacts SET name=?, service=?, phone=?, location=? WHERE id=?",
                (*contact.values(), contact_id)
            )
        if cursor.rowcount == 0:
            return jsonify({"message": "Contact not found"}), 404
        return jsonify({"id": contact_id, **contact})
    except ValueError as exc:
        return jsonify({"message": str(exc)}), 400

@app.delete("/api/contacts/<int:contact_id>")
def api_delete(contact_id):
    with connect_db() as conn:
        cursor = conn.execute("DELETE FROM contacts WHERE id=?", (contact_id,))
    if cursor.rowcount == 0:
        return jsonify({"message": "Contact not found"}), 404
    return jsonify({"message": "Contact deleted"})

if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="127.0.0.1", port=5000)
